package exam02;

public interface BinaryFunction {

	public int apply(int a, int b);
	
	
}
