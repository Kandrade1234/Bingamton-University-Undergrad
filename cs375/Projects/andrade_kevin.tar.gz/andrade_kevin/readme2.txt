Step By Step Instructions to Compile:
-- To Compile:
    -unzip all source files
    -type in "make" onto terminal

-- To Run:
    - ./program2 <filex.txt> <filey.txt> <output2.txt>


Data Structures Used:
-- no data structures used. algorithm is done recursively

Analysis of Computation Time:
-- the computation time would be exponential. O(2^(n+m))

The Classes used:
-- i only used one file and that was a main file.
  Main: contains all source code including function prototypes and definitions. All logic is stored there and no additional files required.
