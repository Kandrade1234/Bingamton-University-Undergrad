Step By Step Instructions to Compile:
-- To Compile:
    -unzip all source files
    -type in "make" onto terminal

-- To Run:
    - ./program1 <filex.txt> <filey.txt> <output1.txt>


Data Structures Used:
-- The only Data structures used on this program are two 2D matrices in dynamic memory(heap). one contains the values and the other contains the path data(directional array)
  i did use some macroguards to make things easier with the directional array.

Analysis of Computation Time:
-- Theta(m x n) where m and n are the lengths of the input strings from each file respectively.

The Classes used:
-- i only used one file and that was a main file.
  Main: contains all source code including function prototypes and definitions. All logic is stored there and no additional files required.
