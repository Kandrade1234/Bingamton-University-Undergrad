Step By Step Instructions to Compile:
-- To Compile:
    -unzip all source files
    -type in "make" onto terminal

-- To Run:
    - ./program3 <filex.txt> <filey.txt> <output3.txt>


Data Structures Used:
-- I use a 2D dynamic array (heap) to store the values of the recursive function. The difference between program 2 and 3 is that this is done with memozation...meaning no repetition of subproblems.

Analysis of Computation Time:
-- the computation time would be theta(m x n) where m and n are the lengths of the input strings stored in each file. 

The Classes used:
-- i only used one file and that was a main file.
  Main: contains all source code including function prototypes and definitions. All logic is stored there and no additional files required.
